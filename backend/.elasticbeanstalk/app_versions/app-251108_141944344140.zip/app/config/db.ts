import { Pool, QueryResult } from "pg";


export class SQLDatabase {
  private pool: Pool;
  private initialized: Promise<void>;

  constructor() {
    this.pool = new Pool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432'),
      database: process.env.DB_NAME || 'testops',
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD || 'password',
      max: 20, // maximum number of clients in the pool
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    this.initialized = this.initializeTable();
  }

  private async initializeTable(): Promise<void> {
    const query = `
      CREATE TABLE IF NOT EXISTS test_runs (
        id TEXT PRIMARY KEY,
        name TEXT,
        status TEXT,
        duration TEXT,
        triggered_at TEXT
      )
    `;
    
    try {
      await this.pool.query(query);
      console.log('Database table initialized successfully');
    } catch (err) {
      console.error('Error initializing table:', err);
      throw err;
    }
  }

  async insertData(
    id: string,
    name: string,
    status: string,
    duration: string | null,
    triggered_at: string,
    callback: (err: Error | null) => void
  ): Promise<void> {
    await this.initialized; // Wait for table to be created
    
    const query = `
      INSERT INTO test_runs (id, name, status, duration, triggered_at)
      VALUES ($1, $2, $3, $4, $5)
    `;
    
    this.pool.query(query, [id, name, status, duration, triggered_at])
      .then(() => callback(null))
      .catch((err: Error | null) => callback(err));
  }

  async getData(id: string, callback: (err: Error | null, row: any) => void): Promise<void> {
    await this.initialized; // Wait for table to be created
    
    const query = 'SELECT * FROM test_runs WHERE id = $1';
    
    this.pool.query(query, [id])
      .then((result: QueryResult) => {
        callback(null, result.rows[0] || null);
      })
      .catch((err: Error) => callback(err, null));
  }

  async getAllData(callback: (err: Error | null, rows: any[]) => void): Promise<void> {
    await this.initialized; // Wait for table to be created
    
    const query = 'SELECT * FROM test_runs ORDER BY triggered_at DESC';
    
    this.pool.query(query)
      .then((result: QueryResult) => {
        callback(null, result.rows);
      })
      .catch((err: Error) => callback(err, []));
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}
